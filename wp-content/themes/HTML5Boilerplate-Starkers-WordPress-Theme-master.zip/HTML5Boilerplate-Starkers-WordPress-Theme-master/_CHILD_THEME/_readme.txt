This is a child theme. Stick this complete directory in the themes root of the wp-content folder and you can build upon the original theme without modifying it too deeply.

I have compressed and minified the original stylesheet so that you don't need to use the @import. It means less rendering time overall.

Be sure to update the meta information in style.css for this theme to include your business name and URL.

Be sure to update the screenshot.png with a screenshot of your child theme.

To find out how to code child themes, see the following webpages:
http://codex.wordpress.org/Child_Themes
http://wpengineer.com/2045/understand-wordpress-child-theme/
